library(testthat)
library(MeinteR)

test_check("MeinteR")
