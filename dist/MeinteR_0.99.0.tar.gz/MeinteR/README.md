![Meinter Logo](vignettes/figs/meinter.png)

MeinteR (MEthylation INTERpretation) is an R package that identifies critical differentially methylated sites, based on the following hypothesis: Critical meth-ylation-mediated changes are more likely in genomic regions enriched in cis-acting regulatory elements than in genomic “deserts”. MeinteR calculates the abundance of co-localized elements, such as transcription factor binding sites, tentative splice sites, and other DNA features, such as G-quadruplexes and palindromes that potentially lead to distinct DNA conformational features and rank them with respect to their putative methylation impact.

---

## Package files

[Binary Package](dist/MeinteR_0.99.0.tgz)

[Source Package](dist/MeinteR_0.99.0.tar.gz)

[Package Vignette (PDF)](vignettes/Meinter_vignette.pdf)

[Package Manual (PDF)](vignettes/MeinteR.pdf) 



## Installation

To install MeinteR and all its dependencies install and load devtools. 

**Local installation ** 
First, download the binary distribution of the package, unzip it to a local folder and run the following commands:
```
library(devtools)
package.folder <- "~/MeinteR"
install_local(package.folder)
```
**Install from bitbucket**

MeinteR and its dependencies can be directly installed using the following command:
```
devtools::install_bitbucket("andigoni/meinter", quiet=FALSE)
```

---





